import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const SobreviveClientApp());

const serverIp = '23.175.144.247';
const serverPort = '19605';
const serverUri = 'minecraft://connect/?serverUrl=$serverIp&serverPort=$serverPort';
const addServerUri = 'minecraft://?addExternalServer=Sobrevive%20a%20Cris%204|$serverIp:$serverPort';

class SobreviveClientApp extends StatelessWidget {
  const SobreviveClientApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Sobrevive a Cris 4 Client',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          colorScheme: const ColorScheme.dark(primary: Color(0xFFB71C1C), secondary: Color(0xFFFF5252)),
          scaffoldBackgroundColor: const Color(0xFF100B0B),
        ),
        home: const LauncherHome(),
      );
}

class LauncherHome extends StatefulWidget {
  const LauncherHome({super.key});
  @override
  State<LauncherHome> createState() => _LauncherHomeState();
}

class _LauncherHomeState extends State<LauncherHome> {
  bool _busy = false;
  String _status = 'Servidor configurado';

  Future<void> _openMinecraft({required bool addServer}) async {
    setState(() { _busy = true; _status = 'Intentando abrir Minecraft…'; });
    final uri = Uri.parse(addServer ? addServerUri : serverUri);
    try {
      final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!mounted) return;
      setState(() => _status = launched
          ? 'Se envió el enlace a Minecraft. Si no se abrió, agrega el servidor manualmente.'
          : 'No se pudo abrir Minecraft. Usa los datos del servidor de abajo.');
    } catch (_) {
      if (!mounted) return;
      setState(() => _status = 'Minecraft no respondió. Usa los datos del servidor de abajo.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: LayoutBuilder(builder: (context, constraints) {
          final wide = constraints.maxWidth > 700;
          return Stack(fit: StackFit.expand, children: [
            Image.asset('assets/images/fondo_original.png', fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFF180707))),
            Container(color: Colors.black.withValues(alpha: 0.48)),
            SafeArea(child: Center(child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: wide ? 56 : 22, vertical: 24),
              child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 680), child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset('assets/images/logo_original.png', height: wide ? 180 : 135,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => const Text('SOBREVIVE A CRIS 4',
                      textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900))),
                  const SizedBox(height: 18),
                  const Text('CLIENT', style: TextStyle(fontSize: 17, letterSpacing: 8, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 30),
                  SizedBox(width: double.infinity, height: 58, child: FilledButton.icon(
                    onPressed: _busy ? null : () => _openMinecraft(addServer: false),
                    icon: const Icon(Icons.play_arrow_rounded, size: 30),
                    label: const Text('JUGAR', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                    style: FilledButton.styleFrom(backgroundColor: const Color(0xFFB71C1C), foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                  )),
                  const SizedBox(height: 12),
                  SizedBox(width: double.infinity, height: 50, child: OutlinedButton.icon(
                    onPressed: _busy ? null : () => _openMinecraft(addServer: true),
                    icon: const Icon(Icons.add_link), label: const Text('AGREGAR SERVIDOR'),
                    style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                  )),
                  const SizedBox(height: 24),
                  Container(width: double.infinity, padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(color: Colors.black.withValues(alpha: .68), borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white24)),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('SERVIDOR OFICIAL', style: TextStyle(color: Color(0xFFFF7777), fontWeight: FontWeight.bold, letterSpacing: 1.4)),
                      const SizedBox(height: 10),
                      const SelectableText(serverIp, style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 3),
                      const SelectableText('Puerto: $serverPort'),
                      const SizedBox(height: 12),
                      Text(_status, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                    ]),
                  ),
                  const SizedBox(height: 16),
                  const Text('Lanzador independiente · Minecraft Bedrock requerido', textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white70, fontSize: 11)),
                ],
              )),
            ))),
            if (_busy) const Positioned(top: 8, right: 8, child: CircularProgressIndicator()),
          ]);
        }),
      );
}
