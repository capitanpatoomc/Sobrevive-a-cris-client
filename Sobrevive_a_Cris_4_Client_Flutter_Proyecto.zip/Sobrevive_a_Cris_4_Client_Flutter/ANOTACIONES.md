# Siguiente trabajo recomendado
1. Ejecutar `flutter create . --platforms=android,windows` para generar los proyectos de plataforma que corresponden a la versión instalada de Flutter.
2. Probar ambos enlaces en dispositivos reales y registrar el comportamiento por versión de Minecraft Bedrock.
3. Añadir icono de aplicación propio, splash screen, gestión de errores y preferencias.
4. Probar la disponibilidad real del servidor desde la red del usuario; el prototipo no hace una comprobación de estado.
