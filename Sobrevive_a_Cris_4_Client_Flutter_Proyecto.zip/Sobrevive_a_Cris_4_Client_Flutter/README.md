# Sobrevive a Cris 4 Client (prototipo Flutter)

Lanzador externo para Minecraft Bedrock con el fondo y logo originales del pack.

- Servidor configurado: `23.175.144.247:19605`
- Botones: Jugar y Agregar servidor
- Recursos: `assets/images/`
- Código principal: `lib/main.dart`
- Guía para compilar desde un teléfono Android: `INSTRUCCIONES_ANDROID_DESDE_CELULAR.md`

## Compilación local

Con Flutter instalado y las plataformas creadas:

```bash
flutter create --platforms=android,windows .
flutter pub get
flutter build apk --release
```

Para Windows, compila en un equipo o runner Windows:

```bash
flutter build windows --release
```

## Compilar sin PC

El flujo `.github/workflows/android-apk.yml` permite compilar el APK en GitHub Actions. Consulta la guía para los pasos desde un teléfono.

**Nota:** los enlaces `minecraft://` son intentos de integración. Deben probarse con la versión concreta de Minecraft Bedrock instalada; no se garantiza que todas las versiones acepten la conexión directa.
