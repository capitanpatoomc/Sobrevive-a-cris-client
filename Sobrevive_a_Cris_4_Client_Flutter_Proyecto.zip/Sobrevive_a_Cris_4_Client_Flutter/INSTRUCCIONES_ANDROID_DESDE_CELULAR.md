# Construir Sobrevive a Cris 4 Client usando solo un celular Android

Este proyecto contiene el código Flutter y las imágenes originales. No es todavía un APK instalado: hay que compilarlo. Como no tienes PC, el flujo preparado usa GitHub Actions para compilar el APK en la nube.

## Pasos

1. Descarga `Sobrevive_a_Cris_4_Client_Flutter_Proyecto.zip` y descomprímelo en el teléfono.
2. En el navegador, entra en https://github.com/ y crea una cuenta o inicia sesión.
3. Crea un repositorio nuevo llamado `Sobrevive-a-Cris-4-Client`. Para empezar, puedes dejarlo **Private**. No necesitas añadir README, licencia ni `.gitignore` porque el proyecto ya tiene archivos.
4. Abre el repositorio y pulsa **Add file → Upload files**. Sube el contenido de la carpeta `Sobrevive_a_Cris_4_Client_Flutter` descomprimida, no el ZIP como único archivo. Asegúrate de que `lib/`, `assets/`, `pubspec.yaml` y `.github/workflows/android-apk.yml` queden en la raíz del repositorio.
5. Pulsa **Commit changes** para guardar los archivos en la rama `main`.
6. Abre la pestaña **Actions** del repositorio. Selecciona **Construir APK Android**. Si aparece el botón **Run workflow**, púlsalo y luego vuelve a confirmar con **Run workflow**.
7. Espera a que el trabajo termine con una marca verde. Abre la ejecución completada y baja hasta **Artifacts**.
8. Descarga `Sobrevive-a-Cris-4-Client-APK.zip` y descomprímelo en el teléfono. Dentro estará `app-release.apk`.
9. Abre el APK. Android podría pedir permiso para instalar aplicaciones desde el navegador o gestor de archivos; permite esa instalación solo si confirmas que el archivo viene de tu propia ejecución del repositorio.
10. Abre Sobrevive a Cris 4 Client y prueba **JUGAR**. Minecraft Bedrock debe estar instalado. El enlace puede abrir Minecraft, pero la conexión automática depende de si tu versión de Minecraft acepta ese tipo de enlace. Si no conecta, usa **AGREGAR SERVIDOR** o introduce la IP y el puerto manualmente.

## Si falla la compilación

- Abre la ejecución fallida de Actions y copia el primer mensaje de error rojo.
- No compartas contraseñas, tokens ni secretos del repositorio.
- Envíame el mensaje de error y te ayudo a corregirlo.

## Importante

- El flujo de trabajo crea la estructura Android automáticamente en el entorno de compilación, así que no necesitas instalar Flutter ni Android Studio en tu celular.
- El APK no está firmado para publicación en Google Play; es una compilación de prueba instalable.
- Este es un lanzador externo, no un cliente que modifique internamente Minecraft.
- Para compilar la versión de Windows se necesitará otro flujo de compilación ejecutado en Windows; este archivo solo construye Android.
